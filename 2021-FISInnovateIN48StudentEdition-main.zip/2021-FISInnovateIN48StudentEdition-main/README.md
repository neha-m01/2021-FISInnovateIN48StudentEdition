# 2021-FISInnovateIN48StudentEdition
Drop your presentations &amp; code in this repo prior to the submission deadline of 10AM EST on Sunday 8/29/21.
